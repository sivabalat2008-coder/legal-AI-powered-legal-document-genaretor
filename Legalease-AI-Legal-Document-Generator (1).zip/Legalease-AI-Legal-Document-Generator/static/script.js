function copyDocument() {
    const text = document.getElementById("documentText").innerText;
    navigator.clipboard.writeText(text).then(() => {
        alert("Document copied.");
    });
}
