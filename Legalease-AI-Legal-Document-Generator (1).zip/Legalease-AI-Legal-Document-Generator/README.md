# Legalease – AI-Powered Legal Document Generator

A college-project prototype that uses Python Flask, SQLite, HTML/CSS/JavaScript, and Google's Gemini API to generate general legal-document drafts.

## Features
- Document-type selection
- User/project details form
- Gemini-powered draft generation
- SQLite history storage
- Copy-to-clipboard
- Responsive UI

## Setup

1. Install Python 3.
2. Open this folder in VS Code.
3. Create a virtual environment:

   python -m venv venv

4. Activate it on Windows:

   venv\Scripts\activate

5. Install dependencies:

   pip install -r requirements.txt

6. Rename `.env.example` to `.env`.
7. Put your Gemini API key in `.env`.
8. Run:

   python app.py

9. Open:

   http://127.0.0.1:5000

## Important
This is an educational prototype. Generated documents are drafts/templates and are not a substitute for advice from a qualified lawyer. Do not upload confidential or sensitive legal information to an AI service unless your project's privacy and security requirements permit it.
