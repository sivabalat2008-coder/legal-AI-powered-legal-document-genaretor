import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request
from dotenv import load_dotenv
from google import genai

load_dotenv()

app = Flask(__name__)
DB_NAME = "legalease.db"
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")


def init_db():
    conn = sqlite3.connect(DB_NAME)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            document_type TEXT NOT NULL,
            user_name TEXT NOT NULL,
            details TEXT NOT NULL,
            generated_text TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def generate_document(document_type, user_name, details):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured in the .env file.")

    client = genai.Client(api_key=api_key)

    prompt = f"""
You are a legal-document drafting assistant for an educational software project.
Create a GENERAL DRAFT of a {document_type} based only on the information supplied below.

User name: {user_name}
Details:
{details}

Requirements:
- Clearly label the output as a draft/template.
- Use placeholders such as [DATE], [ADDRESS], [PARTY NAME] where information is missing.
- Use clear, neutral language.
- Do not claim the document is legally valid in any particular jurisdiction.
- Do not provide legal advice, legal conclusions, or instructions to evade law.
- Do not invent laws, court cases, statutes, or citations.
- End with: "Review this draft with a qualified legal professional before signing or using it."
"""

    response = client.models.generate_content(
        model=MODEL,
        contents=prompt
    )
    return response.text or "No document was generated."


@app.route("/", methods=["GET", "POST"])
def index():
    document = None
    error = None

    if request.method == "POST":
        document_type = request.form.get("document_type", "").strip()
        user_name = request.form.get("user_name", "").strip()
        details = request.form.get("details", "").strip()

        if not document_type or not user_name or not details:
            error = "Please fill in all fields."
        else:
            try:
                document = generate_document(document_type, user_name, details)

                conn = sqlite3.connect(DB_NAME)
                conn.execute(
                    """INSERT INTO documents
                       (document_type, user_name, details, generated_text, created_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (document_type, user_name, details, document,
                     datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                )
                conn.commit()
                conn.close()
            except Exception as exc:
                error = str(exc)

    return render_template(
        "index.html",
        document=document,
        error=error
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
